package kr.co.wlife.common.batch.history.mapper;


import org.apache.ibatis.annotations.Mapper;

import java.lang.annotation.*;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Mapper   // 선택사항
public @interface MetaMapper {
}

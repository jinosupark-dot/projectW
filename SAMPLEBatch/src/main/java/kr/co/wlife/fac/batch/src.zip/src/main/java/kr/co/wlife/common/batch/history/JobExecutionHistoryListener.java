package kr.co.wlife.common.batch.history;

import kr.co.wlife.common.batch.history.vo.JobExecutionHistoryDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.stereotype.Component;

import java.net.InetAddress;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
public class JobExecutionHistoryListener implements JobExecutionListener {

    private static final String HOSTNAME = resolveHostname();
    private static final String PID = String.valueOf(ProcessHandle.current().pid());
    private static final DateTimeFormatter YMD = DateTimeFormatter.ofPattern("yyyyMMdd");
    private static final int MSG_MAX_LENGTH = 2500;   // BTCH_END_MSG_DTL_TEXT 컬럼 길이에 맞춰 조정
    private static final int PRMT_MAX_LENGTH = 2500;

    private final JobExecutionHistoryRepository repository;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        log.info("JobExecutionHistoryListener.beforeJob 호출됨. jobExecutionId={} 20261028 10:47", jobExecution.getId());
        System.out.println("JobExecutionHistoryListener.afterJob 호출됨. ");

        try {
            //log.info("AAA ------- before repository.insert JobExecutionHistoryListener.afterJob . jobExecutionId={} 20261022 16:30", jobExecution.getId());
            System.out.println("AAA ------ before repository.insert JobExecutionHistoryListener.beforeJob . ");

            JobExecutionHistoryDTO dto = toDto(jobExecution);
            repository.insert(dto);   // selectKey / useGeneratedKeys로 dto.btchPrcsSeq 채워져야 함

            // 생성된 시퀀스를 ExecutionContext에 보관 (afterJob에서 사용)
            if (dto.getBtchPrcsSeq() != null) {
                jobExecution.getExecutionContext().putLong("btchPrcsSeq", dto.getBtchPrcsSeq());
            }

        } catch (Exception e) {
            e.printStackTrace();   // 임시 TODO
            // TODO - check logging
            // 이력 적재 실패가 Job 결과에 영향을 주면 안 되므로 로그만 남김
            log.error("BATCH_JOB_EXECUTION_HISTORY 적재 실패 (insert). jobExecutionId={}",
                    jobExecution.getId(), e);
        }
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        log.info("JobExecutionHistoryListener.afterJob 호출됨. jobExecutionId={} 20261028 10:47", jobExecution.getId());
        System.out.println("JobExecutionHistoryListener.afterJob 호출됨. ");

        try {
            //log.info("AAA ------- before repository.insert JobExecutionHistoryListener.afterJob . jobExecutionId={} 20261022 16:30", jobExecution.getId());
            System.out.println("AAA ------ before repository.update JobExecutionHistoryListener.afterJob . ");

            //TODO recover repository.update(toDto(jobExecution));
            repository.update(toDto(jobExecution));

        } catch (Exception e) {
            e.printStackTrace();   // 임시 TODO
            // TODO - check logging
            // 이력 적재 실패가 Job 결과에 영향을 주면 안 되므로 로그만 남김
            log.error("BATCH_JOB_EXECUTION_HISTORY 적재 실패 (update). jobExecutionId={}",
                    jobExecution.getId(), e);
        }
    }

    private JobExecutionHistoryDTO toDto(JobExecution je) {
        long readCount = 0;
        long commitCount = 0;

        for (StepExecution se : je.getStepExecutions()) {
            readCount += se.getReadCount();
            commitCount += se.getCommitCount();
        }

        String prcsDt = je.getJobParameters().getString("prcsDt");
        if (prcsDt == null) {
            prcsDt = LocalDate.now().format(YMD);
        }

        // ExecutionContext에서 기존에 저장된 시퀀스 번호 조회 (없으면 null)
        Long btchPrcsSeq = (Long) je.getExecutionContext().get("btchPrcsSeq");


        return JobExecutionHistoryDTO.builder()
                .btchPrcsSeq(btchPrcsSeq)
                .btchId(je.getJobInstance().getJobName())
                .schdBtchId(je.getJobParameters().getString("schdBtchId"))
                .prcsDt(prcsDt)
                .jobExecutionId(je.getId())
                .btchWorkStatCd(je.getStatus().name())
                .workStrtDtime(je.getStartTime())
                .workEndDtime(je.getEndTime())
                .readCount(readCount)
                .commitCount(commitCount)
                .errorCnt((long) je.getAllFailureExceptions().size())
                .btchEndMsgDtlText(truncate(je.getExitStatus().getExitDescription(), MSG_MAX_LENGTH))
                .btchExecSvrDvsnId(HOSTNAME)
                .processId(PID)
                .btchPrmtDtlText(toParamText(je.getJobParameters(), PRMT_MAX_LENGTH))
                .oprtDtlDtime(LocalDateTime.now())
                // oprtStfno, oprtTmno, oprtTrCd - TODO TBD
                .build();
    }

    private static String truncate(String s, int max) {
        return (s == null || s.length() <= max) ? s : s.substring(0, max);
    }

    private static String resolveHostname() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            return "unknown";
        }
    }

    /**
     * JobParameters → "key1=value1,key2=value2" 문자열 변환
     * - 키 기준 정렬(로그 비교가 쉬움)
     * - 파라미터가 없으면 null 반환
     */
    private String toParamText(JobParameters params, int maxLength) {
        if (params == null || params.isEmpty()) {
            return null;
        }

        String text = params.getParameters().entrySet().stream()
                .filter(e -> !"time_for_retriable".equals(e.getKey()))   // 제외 키
                .sorted(java.util.Map.Entry.comparingByKey())
                .map(e -> e.getKey() + "=" + e.getValue().getValue())
                .collect(Collectors.joining(","));

        return truncate(text, maxLength);   // 기존 truncate 재사용
    }
}
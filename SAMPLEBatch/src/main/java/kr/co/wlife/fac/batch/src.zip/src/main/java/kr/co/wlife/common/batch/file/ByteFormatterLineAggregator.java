package kr.co.wlife.common.batch.file;

import org.springframework.batch.item.file.transform.LineAggregator;
import java.nio.charset.Charset;
import java.util.Arrays;

/**
 * 한글 바이트 길이를 정확히 계산하여 고정 길이 라인을 생성하는 커스텀 LineAggregator
 */
public class ByteFormatterLineAggregator<T> implements LineAggregator<T> {

    private final int[] fieldByteLengths; // 각 필드별 할당된 바이트 길이 배열
    private final Charset charset; // 캐릭터셋 (예: EUC-KR, UTF-8)
    private final FieldExtractor<T> fieldExtractor; // VO에서 필드 값을 추출할 Extractor

    public ByteFormatterLineAggregator(int[] fieldByteLengths, String charsetName, FieldExtractor<T> fieldExtractor) {
        this.fieldByteLengths = fieldByteLengths;
        this.charset = Charset.forName(charsetName);
        this.fieldExtractor = fieldExtractor;
    }

    @Override
    public String aggregate(T item) {
        System.out.println("FWKBatch ByteFormatterLineAggregator called");

        Object[] fields = fieldExtractor.extract(item);
        if (fields.length != fieldByteLengths.length) {
            throw new IllegalArgumentException("필드 개수와 바이트 길이 설정 개수가 일치하지 않습니다.");
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < fields.length; i++) {
            String value = fields[i] != null ? fields[i].toString() : "";
            int maxByte = fieldByteLengths[i];

            // 바이트 기준 패딩 처리된 문자열 결합
            sb.append(padRightByByte(value, maxByte, charset));
        }
        return sb.toString();
    }

    /**
     * 바이트 길이 기준 우측 공백 패딩 메서드
     */
    private String padRightByByte(String str, int maxByteLength, Charset charset) {
        try {
            byte[] bytes = str.getBytes(charset);
            if (bytes.length >= maxByteLength) {
                // 초과 시 깨지지 않게 안전하게 자르기
                return new String(bytes, 0, maxByteLength, charset);
            }

            // 부족한 만큼 우측에 공백(0x20) 채우기
            byte[] paddedBytes = new byte[maxByteLength];
            Arrays.fill(paddedBytes, (byte) ' ');
            System.arraycopy(bytes, 0, paddedBytes, 0, bytes.length);

            return new String(paddedBytes, charset);
        } catch (Exception e) {
            return str;
        }
    }

    /**
     * 필드 추출 인터페이스
     */
    public interface FieldExtractor<T> {
        Object[] extract(T item);
    }
}
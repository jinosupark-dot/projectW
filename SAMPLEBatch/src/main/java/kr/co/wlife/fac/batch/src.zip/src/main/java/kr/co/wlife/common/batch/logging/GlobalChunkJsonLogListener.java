package kr.co.wlife.common.batch.logging;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.batch.core.ChunkListener;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

public class GlobalChunkJsonLogListener implements ChunkListener {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final ThreadLocal<Long> chunkStartTime = new ThreadLocal<>();

    // ISO 8601 UTC 타임스탬프를 규격화하기 위한 포맷터 정의 (예: 2026-09-16T16:54:30.123Z)
    private static final DateTimeFormatter ISO_UTC_FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").withZone(ZoneOffset.UTC);

    @Override
    public void beforeChunk(ChunkContext context) {
        chunkStartTime.set(System.currentTimeMillis());
    }

    @Override
    public void afterChunk(ChunkContext context) {
        logChunkResult(context, "COMPLETED");
    }

    @Override
    public void afterChunkError(ChunkContext context) {
        logChunkResult(context, "FAILED");
    }

    private void logChunkResult(ChunkContext context, String status) {
        try {
            long durationMs = 0;
            if (chunkStartTime.get() != null) {
                durationMs = System.currentTimeMillis() - chunkStartTime.get();
            }

            StepContext stepContext = context.getStepContext();
            StepExecution stepExecution = stepContext.getStepExecution();

            Map<String, Object> jsonMap = new LinkedHashMap<>();

            //Chunk별 실행 시간 및 처리량 집계
            jsonMap.put("timestamp", ISO_UTC_FORMATTER.format(Instant.now()));
            jsonMap.put("logtype", "BATCH_CHUNK_METRIC");
            jsonMap.put("status", status);
            jsonMap.put("duration_ms", durationMs);
            jsonMap.put("job_name", stepExecution.getJobExecution().getJobInstance().getJobName());
            jsonMap.put("step_name", stepContext.getStepName());
            jsonMap.put("job_execution_id", stepExecution.getJobExecutionId());
            jsonMap.put("step_execution_id", stepExecution.getId());
            jsonMap.put("read_count", stepExecution.getReadCount());
            jsonMap.put("write_count", stepExecution.getWriteCount());
            jsonMap.put("commit_count", stepExecution.getCommitCount());
            jsonMap.put("rollback_count", stepExecution.getRollbackCount());

            // JSON 문자열 변환 및 파일 전용 로거 호출
            String jsonOutput = objectMapper.writeValueAsString(jsonMap);
            org.slf4j.LoggerFactory.getLogger("CHUNK_JSON_FILE_LOGGER").info(jsonOutput);

        } catch (Exception e) {
            org.slf4j.LoggerFactory.getLogger(GlobalChunkJsonLogListener.class).error("Failed to write chunk json log", e);
        } finally {
            chunkStartTime.remove();
        }
    }
}

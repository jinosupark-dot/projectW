package kr.co.wlife.common.batch.history.vo;

import lombok.*;
import lombok.AccessLevel;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JobExecutionHistoryDTO {
    private Long btchPrcsSeq;
    private String btchId;
    private String schdBtchId;
    private String prcsDt;
    private Long jobExecutionId;
    private String btchWorkStatCd;
    private LocalDateTime workStrtDtime;
    private LocalDateTime workEndDtime;
    private Long readCount;
    private Long commitCount;
    private Long errorCnt;
    private String btchEndMsgDtlText;
    private String btchExecSvrDvsnId;
    private String processId;
    private String btchPrmtDtlText;
    private String oprtStfno;
    private String oprtTmno;
    private LocalDateTime oprtDtlDtime;
    private String oprtTrCd;
}

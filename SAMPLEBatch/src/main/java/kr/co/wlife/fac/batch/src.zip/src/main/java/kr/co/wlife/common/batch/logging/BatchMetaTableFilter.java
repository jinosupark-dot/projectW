package kr.co.wlife.common.batch.logging;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.filter.Filter;
import ch.qos.logback.core.spi.FilterReply;

public class BatchMetaTableFilter extends Filter<ILoggingEvent> {

    @Override
    public FilterReply decide(ILoggingEvent event) {
        String message = event.getFormattedMessage();
        if (message == null) {
            return FilterReply.NEUTRAL;
        }

        String lowerMessage = message.toLowerCase();
        String upperMessage = message.toUpperCase();

        // 1.1 프로젝트에서 만든 이력 테이블은 필터링 제외 (쿼리 로그 출력 허용)
        if (! upperMessage.contains("BATCH_JOB_EXECUTION_HISTORY")) {
            // 1.2 스프링 배치 메타 테이블 관련 로그는 차단
            if (upperMessage.contains("BATCH_JOB_") || upperMessage.contains("BATCH_STEP_")) {
                return FilterReply.DENY;
            }
        }

        // 2. {executed in 3 msec} 문자열이 감지되면 숫자만 추출하여 자바 변수에 저장
        if (lowerMessage.contains("executed in")) {
            try {
                // "executed in " 뒤의 숫자 부분만 잘라냅니다.
                int startIdx = lowerMessage.indexOf("executed in ") + "executed in ".length();
                int endIdx = lowerMessage.indexOf(" msec", startIdx);

                if (endIdx == -1) {
                    endIdx = lowerMessage.indexOf(" ms", startIdx);
                }

                if (startIdx > 0 && endIdx > startIdx) {
                    String durationStr = lowerMessage.substring(startIdx, endIdx).trim();
                    long duration = Long.parseLong(durationStr);

                    // 자바 변수(ThreadLocal)에 최종 저장!
                    QueryContext.setExecutionTime(duration);
                }
            } catch (Exception e) {
                // 파싱 에러 발생 시 스트레스 없이 패스
            }
        }

        return FilterReply.NEUTRAL;
    }
}

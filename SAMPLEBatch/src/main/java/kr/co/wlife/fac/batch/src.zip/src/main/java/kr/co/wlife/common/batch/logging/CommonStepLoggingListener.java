package kr.co.wlife.common.batch.logging;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.stereotype.Component;

import java.net.InetAddress;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Slf4j
@Component
public class CommonStepLoggingListener implements StepExecutionListener {

    private static final Logger trLogger = LoggerFactory.getLogger("BatchTransactionLog");
    private static final String PREFIX = "CommonLogging STEP "; // TODO 개발완료 시점에 지울 것
    private static final String LINE = "-------------------------------------------------------------------------";
    private static final String DELIM = "\t";
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss.SSS");
    private static final String HOSTNAME = resolveHostname();

    @Override
    public void beforeStep(StepExecution stepExecution) {
        String stepName = stepExecution.getStepName();
        String jobName = stepExecution.getJobExecution().getJobInstance().getJobName();

        MDC.put("stepName", stepName);

        log.info("{}{}", PREFIX, LINE);
        log.info("{}[STEP START] Job: '{}' (JobExecutionId: {}) -> Step: '{}' (StepExecutionId: {})",
                PREFIX, jobName, stepExecution.getJobExecutionId(), stepName, stepExecution.getId());
        log.info("{}{}", PREFIX, LINE);
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        try {
            String stepName = stepExecution.getStepName();
            String jobName = stepExecution.getJobExecution().getJobInstance().getJobName();
            BatchStatus status = stepExecution.getStatus();
            ExitStatus exitStatus = stepExecution.getExitStatus();

            LocalDateTime start = stepExecution.getStartTime();
            LocalDateTime end = stepExecution.getEndTime() != null ? stepExecution.getEndTime() : LocalDateTime.now();
            long durationMs = start != null ? Duration.between(start, end).toMillis() : -1;

            long readCount = stepExecution.getReadCount();
            long writeCount = stepExecution.getWriteCount();
            long filterCount = stepExecution.getFilterCount();
            long skipCount = stepExecution.getSkipCount();
            long commitCount = stepExecution.getCommitCount();
            long rollbackCount = stepExecution.getRollbackCount();

            List<Throwable> failures = stepExecution.getFailureExceptions();
            boolean failed = status == BatchStatus.FAILED || !failures.isEmpty();

            log.info("{}{}", PREFIX, LINE);
            log.info("{}[STEP END] Step: '{}' | Status: {} | ExitCode: {} | Duration: {}ms",
                    PREFIX, stepName, status, exitStatus.getExitCode(), durationMs);
            log.info("{}[STEP METRIC] Read: {} | Write: {} | Filter: {} | Skip: {}",
                    PREFIX, readCount, writeCount, filterCount, skipCount);
            log.info("{}[STEP METRIC] Commit: {} | Rollback: {}", PREFIX, commitCount, rollbackCount);

            if (failed) {
                log.error("{}[STEP FAILURE DETECTED] '{}' | ExitDescription: {}",
                        PREFIX, stepName, exitStatus.getExitDescription());
                failures.forEach(t ->
                        log.error("{} -> Step Error Message: {}", PREFIX, t.getMessage(), t));
            }
            log.info("{}{}", PREFIX, LINE);

            writeTransactionLog(stepExecution, jobName, stepName, start, durationMs, failed, failures,
                    readCount, writeCount, skipCount);

            // 원래의 ExitStatus를 그대로 반환하여 Batch 흐름(Flow)에 영향을 주지 않음
            return exitStatus;
        } finally {
            MDC.remove("stepName");
        }
    }

    /** 시작일시 / 호스트명 / Job명 / Step명 / StepExecutionId / 결과(OK|ERR) / 처리시간(ms) / ExitCode / Read / Write / Skip / 에러코드 */
    private void writeTransactionLog(StepExecution se, String jobName, String stepName, LocalDateTime start,
                                     long durationMs, boolean failed, List<Throwable> failures,
                                     long readCount, long writeCount, long skipCount) {
        String errorCode = failed
                ? (failures.isEmpty() ? "999" : failures.get(0).getClass().getSimpleName())
                : "";
        trLogger.info(String.join(DELIM,
                start != null ? start.format(TS) : "",
                HOSTNAME,
                jobName,
                stepName,
                String.valueOf(se.getId()),
                failed ? "ERR" : "OK",
                String.valueOf(durationMs),
                se.getExitStatus().getExitCode(),
                String.valueOf(readCount),
                String.valueOf(writeCount),
                String.valueOf(skipCount),
                errorCode));
    }

    private static String resolveHostname() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            return "unknown";
        }
    }
}
package kr.co.wlife.common.batch.logging;

public class QueryContext {
    private static final ThreadLocal<Long> lastExecutionTime = new ThreadLocal<>();

    // 소요 시간 저장 (ms 단위)
    public static void setExecutionTime(long timeMs) {
        lastExecutionTime.set(timeMs);
    }

    // 자바 변수로 소요 시간 가져오기
    public static Long getExecutionTime() {
        return lastExecutionTime.get();
    }

    // 메모리 누수 방지를 위한 초기화 (필수)
    public static void clear() {
        lastExecutionTime.remove();
    }
}

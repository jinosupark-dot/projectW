package kr.co.wlife.common.batch.history;

import kr.co.wlife.common.batch.history.mapper.JobExecutionHistoryMapper;
import kr.co.wlife.common.batch.history.vo.JobExecutionHistoryDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;


@Repository
@RequiredArgsConstructor
public class JobExecutionHistoryRepository {

    private final JobExecutionHistoryMapper mapper;

    public void insert(JobExecutionHistoryDTO dto) {

        System.out.println("AAA BBB------ before mapper.insertJobExecutionHistory" + dto);

        int cnt = mapper.insertJobExecutionHistory(dto);

        System.out.println("AAA BBB ------ after mapper.insertJobExecutionHistory cnt: " + cnt);
    }


    public void update(JobExecutionHistoryDTO dto) {

        System.out.println("AAA BBB------ before mapper.updateJobExecutionHistory" + dto);

        int cnt = mapper.updateJobExecutionHistory(dto);

        System.out.println("AAA BBB ------ after mapper.updateJobExecutionHistory cnt: " + cnt);
    }


}
package kr.co.wlife.common.batch.config;

import kr.co.wlife.common.batch.history.mapper.MetaMapper;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.type.JdbcType;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import javax.sql.DataSource;

@Configuration
@MapperScan(
        basePackages = "kr.co.wlife.common.batch.history.mapper",
        annotationClass = MetaMapper.class,
        sqlSessionFactoryRef = "metaSqlSessionFactory")
public class MetaMyBatisConfig {

    @Bean
    public SqlSessionFactory metaSqlSessionFactory(
            @Qualifier("metaDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean factory = new SqlSessionFactoryBean();
        factory.setDataSource(dataSource);
        factory.setMapperLocations(
                new PathMatchingResourcePatternResolver()
                        .getResources("classpath*:mapper/meta/*.xml"));

        org.apache.ibatis.session.Configuration cfg = new org.apache.ibatis.session.Configuration();
        cfg.setMapUnderscoreToCamelCase(true);
        cfg.setJdbcTypeForNull(JdbcType.NULL);   // null 입력값 처리
        factory.setConfiguration(cfg);
        return factory.getObject();
    }

    @Bean
    public SqlSessionTemplate metaSqlSessionTemplate(
            @Qualifier("metaSqlSessionFactory") SqlSessionFactory factory) {
        return new SqlSessionTemplate(factory);
    }
}
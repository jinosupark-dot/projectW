package kr.co.wlife.common.batch.builder;

import kr.co.wlife.common.batch.history.JobExecutionHistoryListener;
import kr.co.wlife.common.batch.logging.CommonJobLoggingListener;
import kr.co.wlife.common.batch.logging.CommonStepLoggingListener;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.builder.TaskletStepBuilder;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;

@Component
@RequiredArgsConstructor
public class CommonBatchBuilders {

    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;
    private final CommonJobLoggingListener jobListener;
    private final CommonStepLoggingListener stepListener;
    private final JobExecutionHistoryListener historyListener;

    /** 공통 리스너가 이미 등록된 JobBuilder */
    public JobBuilder jobBuilder(String name) {

        return new JobBuilder(name, jobRepository)
                .listener(jobListener)
                .listener(historyListener);
    }

    /** 공통 리스너가 이미 등록된 StepBuilder */
    public StepBuilder stepBuilder(String name) {
        return new StepBuilder(name, jobRepository)
                .listener(stepListener);
    }

    /* ================================================================
     * tasklet
     */
    /**
     * 공통 리스너 + Tasklet이 등록된 TaskletStepBuilder.
     * 추가 옵션(allowStartIfComplete, startLimit 등)이 필요할 때 사용
     */
    public TaskletStepBuilder taskletStepBuilder(String name, Tasklet tasklet) {
        return stepBuilder(name).tasklet(tasklet, transactionManager);
    }

    /** 바로 Step으로 반환 (대부분의 경우 이것만 사용) */
    public Step taskletStep(String name, Tasklet tasklet) {
        return taskletStepBuilder(name, tasklet).build();
    }

    /**
     * 람다 전용: 완료 시 RepeatStatus.FINISHED 자동 반환
     *
     * @param name   Step 이름 (BATCH_STEP_EXECUTION.STEP_NAME 에 기록됨)
     * @param action 실행할 업무 로직. 매개변수/반환값이 없는 Runnable이라
     *               StepContribution, ChunkContext에 접근할 수 없음 (단순 작업용)
     */
    public Step taskletStep(String name, Runnable action) {
        return taskletStep(name, (
                // StepContribution: 이번 트랜잭션(청크)에서 수행한 결과를 StepExecution에 반영하는 객체
                //   예) contribution.incrementWriteCount(n) → 쓰기 건수 누적
                //       contribution.setExitStatus(...)    → Step 종료 상태 지정
                contribution,
                // ChunkContext: 현재 실행 중인 Step/Job의 문맥 정보
                //   예) chunkContext.getStepContext().getJobParameters() → Job 파라미터 조회
                //       chunkContext.getStepContext().getStepExecution() → StepExecution 접근
                chunkContext) -> {

            // action: 외부에서 전달받은 실제 업무 로직 (여기서 실행됨)
            action.run();

            // RepeatStatus.FINISHED: Tasklet 1회 실행 후 종료 (CONTINUABLE이면 반복 호출됨)
            return RepeatStatus.FINISHED;
        });
    }
    public PlatformTransactionManager tx() {
        return transactionManager;
    }
}
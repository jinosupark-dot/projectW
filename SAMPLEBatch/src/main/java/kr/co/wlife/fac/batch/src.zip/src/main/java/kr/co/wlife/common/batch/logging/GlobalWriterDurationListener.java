package kr.co.wlife.common.batch.logging;

import org.springframework.batch.core.ItemWriteListener;
import org.springframework.batch.item.Chunk;
import org.springframework.stereotype.Component;

@Component
public class GlobalWriterDurationListener implements ItemWriteListener<Object> {

    @Override
    public void beforeWrite(Chunk<? extends Object> items) {
        // 쓰기 전처리 (필요시)
    }

    @Override
    public void afterWrite(Chunk<? extends Object> items) {
        // 💡 핵심: MyBatis가 방금 일괄 인서트(Batch Insert)를 끝낸 직후의 소요 시간을 가져옵니다.
        Long insertDuration = QueryContext.getExecutionTime();

        System.out.println("INSERT sqlDuration : " + insertDuration + " ms (처리된 아이템 수: " + items.size() + "개)");

        // ⚠️ 다음 청크나 쿼리에 영향을 주지 않도록 사용 후 초기화해 줍니다.
        QueryContext.clear();
    }

    @Override
    public void onWriteError(Exception exception, Chunk<? extends Object> items) {
        QueryContext.clear();
    }
}

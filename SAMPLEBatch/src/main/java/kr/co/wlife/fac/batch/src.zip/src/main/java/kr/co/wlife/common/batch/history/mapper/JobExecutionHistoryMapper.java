package kr.co.wlife.common.batch.history.mapper;

import kr.co.wlife.common.batch.history.vo.JobExecutionHistoryDTO;

@MetaMapper
public interface JobExecutionHistoryMapper {
    int insertJobExecutionHistory(JobExecutionHistoryDTO dto);
    int updateJobExecutionHistory(JobExecutionHistoryDTO dto);
}
package kr.co.wlife.common.batch.file;

import org.springframework.batch.item.file.transform.DefaultFieldSet;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.batch.item.file.transform.LineTokenizer;

import java.nio.charset.Charset;
import java.util.Arrays;

/**
 * 한글 바이트 길이를 정확히 계산하여 고정 길이 라인을 파싱하는 커스텀 LineTokenizer
 */
public class ByteFixedLengthTokenizer implements LineTokenizer {

    private final int[] fieldByteLengths; // 각 필드별 바이트 길이 배열
    private final String[] names; // 필드 이름 배열
    private final Charset charset; // 캐릭터셋 (예: EUC-KR)

    public ByteFixedLengthTokenizer(int[] fieldByteLengths, String[] names, String charsetName) {
        this.fieldByteLengths = fieldByteLengths;
        this.names = names;
        this.charset = Charset.forName(charsetName);
    }

    @Override
    public FieldSet tokenize(String line) {
        System.out.println("FWKBatch ByteFixedLengthTokenizer called");
        if (line == null) {
            return new DefaultFieldSet(new String[0], names);
        }

        // 라인 전체를 지정된 인코딩의 바이트 배열로 변환
        byte[] lineBytes = line.getBytes(charset);
        String[] values = new String[fieldByteLengths.length];
        int currentPos = 0;

        for (int i = 0; i < fieldByteLengths.length; i++) {
            int length = fieldByteLengths[i];
            int endPos = Math.min(currentPos + length, lineBytes.length);

            if (currentPos >= lineBytes.length) {
                values[i] = "";
            } else {
                // 바이트 범위만큼 잘라내어 문자열로 변환 후 공백 제거(trim)
                byte[] fieldBytes = Arrays.copyOfRange(lineBytes, currentPos, endPos);
                values[i] = new String(fieldBytes, charset).trim();
            }
            currentPos += length;
        }

        return new DefaultFieldSet(values, names);
    }
}

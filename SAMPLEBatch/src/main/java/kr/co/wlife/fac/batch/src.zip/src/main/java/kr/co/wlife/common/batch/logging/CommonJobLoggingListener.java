package kr.co.wlife.common.batch.logging;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;

import java.net.InetAddress;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Slf4j
@Component
public class CommonJobLoggingListener implements JobExecutionListener {

    private static final Logger trLogger = LoggerFactory.getLogger("BatchTransactionLog");
    private static final String PREFIX = "CommonLogging JOB  "; // TODO 개발완료 시점에 지울 것
    private static final String LINE = "=========================================================================";
    private static final String DELIM = "\t";
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss.SSS");
    private static final String HOSTNAME = resolveHostname();

    private static final DateTimeFormatter FILE_TS = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
    private static final long PID = ProcessHandle.current().pid();

    @Override
    public void beforeJob(JobExecution jobExecution) {
        String jobName = jobExecution.getJobInstance().getJobName();

        // ./logs/{jobName}.{pid}.{yyyyMMddHHmmss}.log 의 확장자 앞부분
        String logFile = jobName + "." + PID + "." + LocalDateTime.now().format(FILE_TS);
        MDC.put("logFile", logFile);
        MDC.put("jobName", jobName);
        MDC.put("jobExecutionId", String.valueOf(jobExecution.getId()));

        log.info("{}{}", PREFIX, LINE);
        log.info("{}[BATCH JOB START] Job Name: '{}' | Execution ID: {}", PREFIX, jobName, jobExecution.getId());
        log.info("{}Job Parameter: {}", PREFIX, jobExecution.getJobParameters());
        log.info("{}Start Time: {}", PREFIX, jobExecution.getStartTime());
        log.info("{}{}", PREFIX, LINE);
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        try {
            String jobName = jobExecution.getJobInstance().getJobName();
            BatchStatus status = jobExecution.getStatus();
            LocalDateTime start = jobExecution.getStartTime();
            LocalDateTime end = jobExecution.getEndTime() != null ? jobExecution.getEndTime() : LocalDateTime.now();
            long durationMs = start != null ? Duration.between(start, end).toMillis() : -1;

            List<Throwable> failures = jobExecution.getAllFailureExceptions();
            boolean failed = status == BatchStatus.FAILED || !failures.isEmpty();

            log.info("{}{}", PREFIX, LINE);
            log.info("{}[BATCH JOB END] Job Name: '{}' | Status: {} | ExitCode: {} | Duration: {}ms",
                    PREFIX, jobName, status, jobExecution.getExitStatus().getExitCode(), durationMs);

            if (failed) {
                log.error("{}[JOB FAILURE DETECTED] '{}' | ExitDescription: {}",
                        PREFIX, jobName, jobExecution.getExitStatus().getExitDescription());
                failures.forEach(t -> log.error("{} -> Error Message: {}", PREFIX, t.getMessage(), t));
            }
            log.info("{}{}", PREFIX, LINE);

            writeTransactionLog(jobExecution, jobName, start, durationMs, failed, failures);
        } finally {
            MDC.remove("jobName");
            MDC.remove("jobExecutionId");
            MDC.remove("logFile");
        }
    }

    /** 요청일시 / 호스트명 / Job명 / ExecutionId / 결과(OK|ERR) / 처리시간(ms) / ExitCode / 에러코드 */
    private void writeTransactionLog(JobExecution je, String jobName, LocalDateTime start,
                                     long durationMs, boolean failed, List<Throwable> failures) {
        String errorCode = failed
                ? (failures.isEmpty() ? "999" : failures.get(0).getClass().getSimpleName())
                : "";
        trLogger.info(String.join(DELIM,
                start != null ? start.format(TS) : "",
                HOSTNAME,
                jobName,
                String.valueOf(je.getId()),
                failed ? "ERR" : "OK",
                String.valueOf(durationMs),
                je.getExitStatus().getExitCode(),
                errorCode));
    }

    private static String resolveHostname() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            return "unknown";
        }
    }
}